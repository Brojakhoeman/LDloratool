import { app } from "../../scripts/app.js";

// ─────────────────────────────────────────────────────────────────────────────
// LoRa-Daddy — Pose Selector  v1.1
// ─────────────────────────────────────────────────────────────────────────────

const THEMES = {
  a: { name:"JADE",   bg0:"#0e0e0e", bg1:"#141414", bg2:"#1a1a1a", accent:"#00FFCC", accent2:"#2196F3", accentW:"woman", text:"#dddddd", textDim:"#333333", textMid:"#666666", border:"#2a2a2a", btnBg:"#00FFCC18", btnBd:"#00FFCC55", btnTx:"#00FFCC", selFill:"#00FFCC14", selBd:"#00FFCC", grpBg:"#00FFCC08", grpTx:"#00FFCCaa", chk:"#00FFCC", lblSel:"#00FFCC", lblOff:"#aaaaaa" },
  b: { name:"NEON",   bg0:"#0a0b14", bg1:"#0d0e1a", bg2:"#111220", accent:"#ff2d88", accent2:"#bf5fff", text:"#9ba0cc", textDim:"#1a1a2a", textMid:"#5050a0", border:"#1a1a2a", btnBg:"#ff2d8818", btnBd:"#ff2d8855", btnTx:"#ff2d88", selFill:"#ff2d8814", selBd:"#ff2d88", grpBg:"#ff2d8808", grpTx:"#ff2d88aa", chk:"#ff2d88", lblSel:"#ff2d88", lblOff:"#9090bb" },
  c: { name:"STUDIO", bg0:"#171410", bg1:"#1e1a15", bg2:"#231f19", accent:"#F5A623", accent2:"#e07b39", text:"#c8b898", textDim:"#3a3028", textMid:"#7a6848", border:"#3a3028", btnBg:"#F5A62318", btnBd:"#F5A62355", btnTx:"#F5A623", selFill:"#F5A62314", selBd:"#F5A623", grpBg:"#F5A62308", grpTx:"#F5A623aa", chk:"#F5A623", lblSel:"#F5A623", lblOff:"#aa9070" },
  d: { name:"OLED",   bg0:"#000000", bg1:"#050505", bg2:"#080808", accent:"#00e5ff", accent2:"#ff6b35", text:"#ffffff", textDim:"#222222", textMid:"#555555", border:"#111111", btnBg:"#00e5ff0a", btnBd:"#00e5ff33", btnTx:"#00e5ff", selFill:"#00e5ff10", selBd:"#00e5ff", grpBg:"#00e5ff06", grpTx:"#00e5ffaa", chk:"#00e5ff", lblSel:"#00e5ff", lblOff:"#aaaaaa" },
};
const THEME_ORDER = ["a","b","c","d"];

const POSES = [
  { id:"P02", label:"Face Front",     group:"FACE",      thumb:"P02_macro_face_straight_on" },
  { id:"P39", label:"Face Macro",     group:"FACE",      thumb:"P39_face_macro_straight_on" },
  { id:"P21", label:"Eye Macro",      group:"FACE",      thumb:"P21_macro_eye_closeup" },
  { id:"P26", label:"Lips Macro",     group:"FACE",      thumb:"P26_lips_macro_closeup" },
  { id:"P06", label:"Face Upward",    group:"FACE",      thumb:"P06_macro_face_upward_tilt_extreme" },
  { id:"P16", label:"Face Overhead",  group:"FACE",      thumb:"P16_overhead_face_macro" },
  { id:"P37", label:"45° Right Bust", group:"HEAD",      thumb:"P37_right_45_bust" },
  { id:"P36", label:"Front Bust",     group:"HEAD",      thumb:"P36_front_bust_upward_gaze" },
  { id:"P38", label:"Top-Down Bust",  group:"HEAD",      thumb:"P38_top_down_three_quarter_bust" },
  { id:"P07", label:"90° Right",      group:"HEAD",      thumb:"P07_face_90_degree_side_profile_right" },
  { id:"P11", label:"90° Left",       group:"HEAD",      thumb:"P11_face_90_degree_side_profile_left" },
  { id:"P30", label:"45° Left Close", group:"HEAD",      thumb:"P30_face_45_left_closeup" },
  { id:"P20", label:"Chest Down",     group:"FULL BODY",      thumb:"P20_chest_downward_angle" },
  { id:"P12", label:"3/4 Front",      group:"FULL BODY", thumb:"P12_three_quarter_body_front_knees_to_head" },
  { id:"P19", label:"Side Left",      group:"FULL BODY", thumb:"P19_full_body_side_profile_left" },
  { id:"P29", label:"Side Right",     group:"FULL BODY", thumb:"P29_full_body_side_profile_right" },
  { id:"P31", label:"Rear Full",      group:"FULL BODY", thumb:"P31_rear_full_body_standing_nude" },
  { id:"P32", label:"Rear 3/4",       group:"FULL BODY", thumb:"P32_rear_three_quarter_full_body" },
  { id:"P33", label:"Over Shoulder",  group:"FULL BODY", thumb:"P33_over_shoulder_look_back" },
  { id:"P08", label:"Aerial",         group:"FULL BODY", thumb:"P08_aerial_overhead_full_body" },
  { id:"P27", label:"High 3/4",       group:"FULL BODY", thumb:"P27_high_angle_three_quarter_full_body" },
  { id:"P22", label:"Lying Overhead", group:"FULL BODY", thumb:"P22_overhead_lying_flat_full_body" },
  { id:"P09", label:"Torso Front",    group:"MEDIUM",    thumb:"P09_medium_torso_front_shoulders_to_hips" },
  { id:"P14", label:"Rear Waist-Up",  group:"MEDIUM",    thumb:"P14_rear_medium_shot_waist_to_head" },
  { id:"P13", label:"Seated Front",   group:"MEDIUM",    thumb:"P13_seated_front_full_body" },
  { id:"P17", label:"Kneeling",       group:"MEDIUM",    thumb:"P17_kneeling_front_full_body" },
  { id:"P35", label:"Wide Squat",     group:"MEDIUM",    thumb:"P35_wide_squat_front" },
  { id:"P24", label:"Bent Rear",      group:"MEDIUM",    thumb:"P24_bent_forward_rear_overhead" },
  { id:"P10", label:"Chest Upward",   group:"LOWER",     thumb:"P10_chest_closeup_upward_angle" },
  { id:"P23", label:"Waist Front",    group:"LOWER",     thumb:"P23_waist_height_front_medium" },
  { id:"P18", label:"Rear Lower",     group:"LOWER",     thumb:"P18_rear_lower_back_closeup" },
  { id:"P01", label:"Groin Front",    group:"LOWER",     thumb:"P01_macro_groin_standing_front" },
  { id:"P04", label:"Low Upward",     group:"LOWER",     thumb:"P04_low_angle_upward_full_body_groin" },
  { id:"P25", label:"Ground Rear",    group:"LOWER",     thumb:"P25_ground_level_rear_low_angle" },
];

const POSE_PROMPTS = {
  P02:"Camera positioned directly in front of the subject at eye level, subject centered in frame, neutral expression, straight-on portrait composition",
  P39:"Camera close to the subject's face from straight on, extreme face macro, face filling entire frame from chin to forehead",
  P21:"Camera extremely close to the subject's eyes, macro eye close-up, both eyes filling the frame",
  P26:"Extreme close-up of the subject's lips and lower face, chin to nose filling the frame",
  P06:"Camera extremely close to the subject's face, slight upward angle, chin tilted up, face filling entire frame",
  P16:"Camera directly above the subject's face looking straight down, overhead face macro, face filling frame",
  P03:"Camera angled 45 degrees to the subject's left side, subject's profile partially visible, medium close-up framing from shoulders upward",
  P37:"Camera angled 45 degrees to the subject's right side, subject's profile partially visible, medium close-up framing from shoulders upward",
  P36:"Camera positioned directly in front of the subject at eye level, medium close-up framed from shoulders to top of head, slight upward gaze",
  P38:"Camera positioned slightly above and in front, looking down at subject's face, three-quarter face view, framed from shoulders upward",
  P07:"Camera positioned at 90 degrees to the subject's right, pure side profile, full head and neck visible",
  P11:"Camera positioned at 90 degrees to the subject's left, pure left side profile, full head and neck visible",
  P30:"Camera close to the subject's face from the left side at 45 degrees, cheek and partial profile filling frame",
  P20:"Camera framing from the chest upward at a slight downward angle, face and chest visible, looking down at subject",
  P12:"Camera framing the subject from the knees upward, subject standing, three-quarter body shot from the front",
  P19:"Camera positioned at the subject's side, full body side profile from head to feet, 90 degrees left, naked, fully nude, no clothing",
  P29:"Camera positioned at the subject's right side, full body side profile from head to feet, 90 degrees right, naked, fully nude, no clothing",
  P31:"Camera positioned directly behind the subject, rear view, full nude figure visible from head to feet, naked, fully nude, no clothing",
  P32:"Camera positioned behind and to the right at 45 degrees, rear three-quarter view, full body visible, naked, fully nude, no clothing",
  P33:"Subject looking back over their right shoulder, camera positioned behind at 45 degrees, face partially visible, naked, fully nude, no clothing",
  P08:"Camera positioned high above the subject looking straight down, aerial overhead view, full body visible",
  P27:"Camera positioned above and to the right at 45 degrees, high-angle three-quarter view, full body visible, naked, fully nude, no clothing",
  P22:"Subject lying on their back, camera above looking down, full body visible from overhead while lying flat, naked, fully nude, no clothing",
  P09:"Medium shot of the subject's chest and torso from the front, framed from shoulders to hips",
  P14:"Camera close behind the subject, rear medium shot framed from waist to head, back of head and shoulders",
  P13:"Subject seated on the ground, camera at eye level in front, legs extended forward, full seated body visible from head to feet, naked, fully nude, no clothing",
  P17:"Subject kneeling, camera at eye level in front, full kneeling body visible, naked, fully nude, no clothing",
  P35:"Subject in a wide squat position, camera at eye level in front, knees apart, full body visible, naked, fully nude, no clothing",
  P24:"Subject bent forward at the waist, camera behind and above, rear three-quarter overhead view, naked, fully nude, no clothing",
  P10:"Camera close to the subject's chest from slightly below, breasts and collarbone filling the frame, upward angle",
  P23:"Camera positioned at waist height in front of the subject, waist and hips centered, medium close-up, naked, fully nude, no clothing",
  P18:"Camera close to the subject's lower back and rear, medium close-up of the back from waist down, rear view, naked, fully nude, no clothing",
  P01:"Close-up shot focused on the hips and groin area, subject standing, lower body filling frame",
  P04:"Camera placed low, aimed upward toward the subject's lower torso, subject standing with legs apart, lower body filling the entire frame from below",
  P15:"Camera positioned low at ground level looking straight up between the subject's legs, subject standing over camera, extreme upward perspective, full nude body visible from below, naked, fully nude, no clothing, genitals visible",
  P25:"Camera at floor level behind the subject, low rear angle, legs and lower body from behind at ground level, naked, fully nude, no clothing",
};

const GROUPS = ["FACE","HEAD","FULL BODY","MEDIUM","LOWER"];

// ── Fixed layout constants ────────────────────────────────────────────────────
const PAD       = 10;
const HDR_H     = 80;   // ComfyUI title bar + 2 output slot rows (prompts + captions)
const CTRL_H    = 100;  // our controls panel (fixed height)
const CTRL_Y    = HDR_H + 2;
const GRID_Y    = CTRL_Y + CTRL_H + 4;  // where scrollable grid starts
const THUMB_S   = 76;
const CELL_GAP  = 6;
const CELL_W    = THUMB_S + CELL_GAP;
const CELL_H    = THUMB_S + 22;  // thumb + label
const GRP_H     = 18;
const DEFAULT_W = 460;
const DEFAULT_VISIBLE_H = 600; // visible grid area height

// ── Image cache ───────────────────────────────────────────────────────────────
const imgCache = new Map();

function loadThumb(key) {
  if (imgCache.has(key)) return;
  imgCache.set(key, null);
  const candidates = [
    `/pose_selector/thumb/${key}.png`,
    `/extensions/ComfyUI-PoseSelector/thumbnails/${key}.png`,
  ];
  function tryUrl(i) {
    if (i >= candidates.length) { imgCache.set(key, "x"); return; }
    const img = new Image();
    img.onload  = () => { imgCache.set(key, img); app.graph.setDirtyCanvas(true); };
    img.onerror = () => tryUrl(i + 1);
    img.src = candidates[i];
  }
  tryUrl(0);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function rr(ctx, x, y, w, h, r = 3) {
  ctx.beginPath(); ctx.roundRect(x, y, w, h, r);
}

function cols(nodeW) {
  const available = nodeW - PAD * 2;
  return Math.max(2, Math.floor(available / CELL_W));
}

// Build flat layout with y positions for given column count
function buildLayout(numCols) {
  const items = []; // {pose, col, row, secY, groupLabel, groupY, groupPoses}
  let y = 0;
  for (const group of GROUPS) {
    const poses = POSES.filter(p => p.group === group);
    const rows  = Math.ceil(poses.length / numCols);
    const groupStart = y;
    y += GRP_H;
    poses.forEach((pose, i) => {
      items.push({
        pose,
        col: i % numCols,
        row: Math.floor(i / numCols),
        y: groupStart + GRP_H + Math.floor(i / numCols) * CELL_H,
        group, groupY: groupStart, groupPoses: poses.map(p => p.id),
        isFirst: i === 0,
      });
    });
    y += rows * CELL_H + 6;
  }
  return { items, totalH: y };
}

// ─────────────────────────────────────────────────────────────────────────────
class PoseSelectorUI {
  #n;
  #sel    = new Set();
  #hits   = [];
  #theme  = "a";
  #scrollY = 0;   // scroll offset in grid-space pixels
  #isDragging = false;
  #dragStartY = 0;
  #dragStartScroll = 0;

  #wSel; #wGender; #wNude;

  constructor(node) {
    this.#n = node;
    const ws = node.widgets || [];
    this.#wSel    = ws.find(w => w.name === "selected_poses");
    this.#wGender = ws.find(w => w.name === "gender");
    this.#wNude   = ws.find(w => w.name === "nude");

    // Hide ALL default widgets - we manage everything via canvas
    for (const w of ws) {
      w.draw = ()=>{};
      w.computeSize = ()=>[0,-4];
      w.type = "hidden";
    }

    const saved = this.#wSel?.value || "";
    saved.split(",").forEach(id => { if (id.trim()) this.#sel.add(id.trim()); });
    if (node.properties?.ps_theme) this.#theme = node.properties.ps_theme;
    if (node.properties?.ps_scroll) this.#scrollY = node.properties.ps_scroll;

    node.size[0] = DEFAULT_W;
    node.size[1] = GRID_Y + DEFAULT_VISIBLE_H;

    POSES.forEach(p => loadThumb(p.thumb));
    this.#attachEvents();
  }

  #t() { return THEMES[this.#theme] || THEMES.a; }

  #sync() {
    if (!this.#wSel) return;
    this.#wSel.value = POSES.filter(p => this.#sel.has(p.id)).map(p => p.id).join(",");
  }

  #gridH() {
    return this.#n.size[1] - GRID_Y;
  }

  #clampScroll(v, totalH) {
    const maxScroll = Math.max(0, totalH - this.#gridH());
    return Math.max(0, Math.min(v, maxScroll));
  }

  // ── Events ────────────────────────────────────────────────────────────────

  #attachEvents() {
    const self = this;

    this.#n.onMouseDown = function(e, pos) {
      const [mx, my] = pos;

      // Scrollbar drag
      const sb = self.#scrollbarRect();
      if (sb && mx >= sb.x && mx <= sb.x + sb.w && my >= sb.y && my <= sb.y + sb.h) {
        self.#isDragging = true;
        self.#dragStartY = my;
        self.#dragStartScroll = self.#scrollY;
        return true;
      }

      // Scroll via click in grid area — mousewheel handled separately
      if (my >= GRID_Y) {
        // Check hit areas (adjusted for scroll)
        for (const h of self.#hits) {
          if (mx >= h.x && mx <= h.x+h.w && my >= h.y && my <= h.y+h.h) {
            h.fn();
            self.#sync();
            app.graph.setDirtyCanvas(true);
            return true;
          }
        }
      } else {
        // Controls area
        for (const h of self.#hits) {
          if (mx >= h.x && mx <= h.x+h.w && my >= h.y && my <= h.y+h.h) {
            h.fn();
            self.#sync();
            app.graph.setDirtyCanvas(true);
            return true;
          }
        }
      }
    };

    this.#n.onMouseMove = function(e, pos) {
      if (!self.#isDragging) return;
      const [, my] = pos;
      const { layout } = self.#getLayout();
      const trackH = self.#gridH();
      const ratio = layout.totalH > trackH ? layout.totalH / trackH : 1;
      const delta = (my - self.#dragStartY) * ratio;
      self.#scrollY = self.#clampScroll(self.#dragStartScroll + delta, layout.totalH);
      if (self.#n.properties) self.#n.properties.ps_scroll = self.#scrollY;
      app.graph.setDirtyCanvas(true);
    };

    this.#n.onMouseUp = function() {
      self.#isDragging = false;
    };

    this.#n.onMouseWheel = function(e) {
      const { layout } = self.#getLayout();
      self.#scrollY = self.#clampScroll(self.#scrollY + e.deltaY * 0.5, layout.totalH);
      if (self.#n.properties) self.#n.properties.ps_scroll = self.#scrollY;
      app.graph.setDirtyCanvas(true);
      return true; // consume event
    };
  }

  #hit(x, y, w, h, fn) { this.#hits.push({x, y, w, h, fn}); }

  #getLayout() {
    const numCols = cols(this.#n.size[0]);
    const layout  = buildLayout(numCols);
    return { numCols, layout };
  }

  #scrollbarRect() {
    const { layout } = this.#getLayout();
    if (layout.totalH <= this.#gridH()) return null;
    const W      = this.#n.size[0];
    const trackH = this.#gridH();
    const ratio  = trackH / layout.totalH;
    const sbH    = Math.max(30, trackH * ratio);
    const sbY    = GRID_Y + (this.#scrollY / layout.totalH) * trackH;
    return { x: W - 8, y: sbY, w: 5, h: sbH, trackH };
  }

  // ── DRAW ─────────────────────────────────────────────────────────────────

  draw(ctx) {
    if (this.#n.flags?.collapsed) return;
    this.#hits = [];
    const t = this.#t();
    const W = this.#n.size[0];

    this.#drawControls(ctx, t, W);
    this.#drawGrid(ctx, t, W);
    this.#drawScrollbar(ctx, t, W);
  }

  // ── Controls (fixed, non-scrolling) ──────────────────────────────────────

  #drawControls(ctx, t, W) {
    const y0 = CTRL_Y;
    const F  = "Courier New,monospace";
    const x0 = PAD + 10;

    // Panel bg
    ctx.fillStyle = t.bg2;
    rr(ctx, PAD, y0, W - PAD*2, CTRL_H, 5); ctx.fill();
    ctx.strokeStyle = t.border; ctx.lineWidth = 0.5;
    rr(ctx, PAD, y0, W - PAD*2, CTRL_H, 5); ctx.stroke();

    // ── Row 1: Brand  +  Theme btn ──────────────────────────────────────────
    const r1y = y0 + 16;
    ctx.fillStyle = t.btnTx;
    ctx.font = `bold 10px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText("⬡ LoRa-Daddy  POSE SELECTOR", x0, r1y);

    const tbW = 96, tbH = 18, tbX = W - PAD - tbW - 6, tbY = y0 + 5;
    ctx.fillStyle = t.btnBg;
    rr(ctx, tbX, tbY, tbW, tbH, 4); ctx.fill();
    ctx.strokeStyle = t.btnBd; ctx.lineWidth = 0.8;
    rr(ctx, tbX, tbY, tbW, tbH, 4); ctx.stroke();
    ctx.fillStyle = t.btnTx;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "center";
    ctx.fillText(`⬡ THEME: ${t.name}  ▶`, tbX + tbW/2, tbY + 12);
    this.#hit(tbX, tbY, tbW, tbH, () => {
      const i = THEME_ORDER.indexOf(this.#theme);
      this.#theme = THEME_ORDER[(i+1) % THEME_ORDER.length];
      if (this.#n.properties) this.#n.properties.ps_theme = this.#theme;
    });

    // Divider
    ctx.strokeStyle = t.border; ctx.lineWidth = 0.4;
    ctx.beginPath();
    ctx.moveTo(PAD + 8, y0 + 24); ctx.lineTo(W - PAD - 8, y0 + 24);
    ctx.stroke();

    // ── Row 2: GENDER label + 3 buttons ─────────────────────────────────────
    const r2y = y0 + 40;
    ctx.fillStyle = t.textMid;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText("GENDER", x0, r2y + 10);

    const genders = ["neutral","woman","man"];
    const gLabels = ["NEUTRAL","WOMAN","MAN"];
    const gColors = [t.textMid, t.accent, t.accent2];
    const gBW = 64, gBH = 18, gX0 = x0 + 62;
    genders.forEach((g, i) => {
      const bx = gX0 + i * (gBW + 5), by = r2y - 1;
      const active = (this.#wGender?.value || "neutral") === g;
      ctx.fillStyle = active ? gColors[i] + "28" : t.bg0;
      rr(ctx, bx, by, gBW, gBH, 4); ctx.fill();
      ctx.strokeStyle = active ? gColors[i] : t.border;
      ctx.lineWidth = active ? 1.2 : 0.5;
      rr(ctx, bx, by, gBW, gBH, 4); ctx.stroke();
      ctx.fillStyle = active ? gColors[i] : t.textMid;
      ctx.font = `bold 9px '${F}'`;
      ctx.textAlign = "center";
      ctx.fillText(gLabels[i], bx + gBW/2, by + 12);
      this.#hit(bx, by, gBW, gBH, () => { if (this.#wGender) this.#wGender.value = g; });
    });

    // ── Row 3: NUDE toggle  +  SELECT ALL  CLEAR  +  count ──────────────────
    const r3y = y0 + 66;

    // NUDE label
    ctx.fillStyle = t.textMid;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText("NUDE", x0, r3y + 11);

    // Toggle
    const isNude = this.#wNude?.value !== false;
    const tgX = x0 + 46, tgW = 36, tgH = 18, tgY = r3y;
    ctx.fillStyle = isNude ? t.accent + "28" : t.bg0;
    rr(ctx, tgX, tgY, tgW, tgH, 9); ctx.fill();
    ctx.strokeStyle = isNude ? t.accent : t.border;
    ctx.lineWidth = isNude ? 1.2 : 0.5;
    rr(ctx, tgX, tgY, tgW, tgH, 9); ctx.stroke();
    const kx = isNude ? tgX + tgW - 11 : tgX + 4;
    ctx.fillStyle = isNude ? t.accent : t.textMid;
    ctx.beginPath(); ctx.arc(kx + 5, tgY + tgH/2, 6, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = isNude ? t.accent : t.textMid;
    ctx.font = `9px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText(isNude ? "on" : "off", tgX + tgW + 7, r3y + 12);
    this.#hit(tgX, tgY, 80, tgH, () => { if (this.#wNude) this.#wNude.value = !this.#wNude.value; });

    // SELECT ALL button
    const saW = 76, saH = 18, saX = W - PAD - 8 - 50 - 4 - saW - 4, saY = r3y;
    ctx.fillStyle = t.btnBg;
    rr(ctx, saX, saY, saW, saH, 4); ctx.fill();
    ctx.strokeStyle = t.btnBd; ctx.lineWidth = 0.8;
    rr(ctx, saX, saY, saW, saH, 4); ctx.stroke();
    ctx.fillStyle = t.btnTx;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "center";
    ctx.fillText("SELECT ALL", saX + saW/2, saY + 12);
    this.#hit(saX, saY, saW, saH, () => POSES.forEach(p => this.#sel.add(p.id)));

    // CLEAR button
    const clW = 50, clH = 18, clX = W - PAD - 8 - clW, clY = r3y;
    ctx.fillStyle = t.bg1;
    rr(ctx, clX, clY, clW, clH, 4); ctx.fill();
    ctx.strokeStyle = t.border; ctx.lineWidth = 0.5;
    rr(ctx, clX, clY, clW, clH, 4); ctx.stroke();
    ctx.fillStyle = t.textMid;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "center";
    ctx.fillText("CLEAR", clX + clW/2, clY + 12);
    this.#hit(clX, clY, clW, clH, () => this.#sel.clear());

    // Count badge right of toggle
    const n = this.#sel.size;
    ctx.fillStyle = n > 0 ? t.accent : t.textMid;
    ctx.font = `bold 9px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText(`${n} / ${POSES.length}`, tgX + tgW + 36, r3y + 12);
  }

  // ── Grid (scrollable) ─────────────────────────────────────────────────────

  #drawGrid(ctx, t, W) {
    const gridH = this.#gridH();
    const { numCols, layout } = this.#getLayout();

    // Recalculate scroll bounds
    this.#scrollY = this.#clampScroll(this.#scrollY, layout.totalH);

    // Clip to grid area
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, GRID_Y, W, gridH);
    ctx.clip();

    // Translate for scroll
    ctx.translate(0, GRID_Y - this.#scrollY);

    // Only draw items in visible range
    const visTop    = this.#scrollY;
    const visBottom = this.#scrollY + gridH;

    const drawnGroups = new Set();

    for (const item of layout.items) {
      const itemBottom = item.y + CELL_H;
      if (itemBottom < visTop - 20) continue;
      if (item.y > visBottom + 20) continue;

      // Draw group header once
      if (!drawnGroups.has(item.group)) {
        drawnGroups.add(item.group);
        this.#drawGroupHeader(ctx, t, W, item.group, item.groupY, item.groupPoses, numCols);
      }

      const tx = PAD + item.col * CELL_W;
      this.#drawCell(ctx, t, item.pose, tx, item.y, GRID_Y);
    }

    ctx.restore();
  }

  #drawGroupHeader(ctx, t, W, group, gy, groupPoseIds, numCols) {
    const F = "Courier New,monospace";
    ctx.fillStyle = t.grpBg;
    rr(ctx, PAD, gy, W - PAD*2, GRP_H, 3); ctx.fill();
    ctx.strokeStyle = t.border; ctx.lineWidth = 0.3;
    rr(ctx, PAD, gy, W - PAD*2, GRP_H, 3); ctx.stroke();

    ctx.fillStyle = t.grpTx;
    ctx.font = `bold 8px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText(group, PAD + 6, gy + 12);

    // ALL/CLEAR button
    const allOn  = groupPoseIds.every(id => this.#sel.has(id));
    const gbW = 34, gbH = 12, gbX = W - PAD - gbW - 4, gbY = gy + 3;
    ctx.fillStyle = allOn ? t.btnBg : t.bg1;
    rr(ctx, gbX, gbY, gbW, gbH, 3); ctx.fill();
    ctx.strokeStyle = allOn ? t.btnBd : t.border; ctx.lineWidth = 0.4;
    rr(ctx, gbX, gbY, gbW, gbH, 3); ctx.stroke();
    ctx.fillStyle = allOn ? t.btnTx : t.textMid;
    ctx.font = `bold 7px '${F}'`;
    ctx.textAlign = "center";
    ctx.fillText(allOn ? "CLEAR" : "ALL", gbX + gbW/2, gbY + 9);

    // Register hit with scroll-adjusted Y
    this.#hit(gbX, GRID_Y + gy - this.#scrollY, gbW, gbH, () => {
      allOn
        ? groupPoseIds.forEach(id => this.#sel.delete(id))
        : groupPoseIds.forEach(id => this.#sel.add(id));
    });
  }

  #drawCell(ctx, t, pose, tx, ty, gridStartY) {
    const s   = THUMB_S;
    const sel = this.#sel.has(pose.id);
    const img = imgCache.get(pose.thumb);
    const F   = "Courier New,monospace";

    // Card bg
    ctx.fillStyle = sel ? t.selFill : t.bg1;
    rr(ctx, tx, ty, s, s, 4); ctx.fill();
    ctx.strokeStyle = sel ? t.selBd : t.border;
    ctx.lineWidth = sel ? 1.5 : 0.4;
    rr(ctx, tx, ty, s, s, 4); ctx.stroke();

    // Thumbnail
    if (img && img !== "x") {
      ctx.save();
      rr(ctx, tx, ty, s, s, 4); ctx.clip();
      ctx.drawImage(img, tx, ty, s, s);
      if (sel) { ctx.fillStyle = t.selBd + "18"; ctx.fillRect(tx, ty, s, s); }
      ctx.restore();
    } else if (img === "x") {
      ctx.fillStyle = t.textDim + "88";
      ctx.font = `16px '${F}'`;
      ctx.textAlign = "center";
      ctx.fillText("▣", tx + s/2, ty + s/2 + 6);
    } else {
      ctx.fillStyle = t.textDim;
      ctx.font = `8px '${F}'`;
      ctx.textAlign = "center";
      ctx.fillText("···", tx + s/2, ty + s/2 + 3);
    }

    // Check badge
    if (sel) {
      ctx.fillStyle = t.chk;
      ctx.beginPath(); ctx.arc(tx + s - 9, ty + 9, 7, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = "#000"; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(tx+s-13, ty+9); ctx.lineTo(tx+s-10, ty+12); ctx.lineTo(tx+s-5, ty+6);
      ctx.stroke();
    }

    // ID pill
    ctx.fillStyle = t.bg0 + "cc";
    rr(ctx, tx+2, ty+2, 20, 11, 2); ctx.fill();
    ctx.fillStyle = sel ? t.accent : t.textMid;
    ctx.font = `bold 7px '${F}'`;
    ctx.textAlign = "left";
    ctx.fillText(pose.id, tx+3, ty+10);

    // Label
    ctx.fillStyle = sel ? t.lblSel : t.lblOff;
    ctx.font = sel ? `bold 9px '${F}'` : `8px '${F}'`;
    ctx.textAlign = "center";
    ctx.save();
    ctx.beginPath(); ctx.rect(tx, ty+s+1, s, 15); ctx.clip();
    ctx.fillText(pose.label, tx + s/2, ty + s + 11);
    ctx.restore();

    // Hit area — adjusted back to screen space
    const screenY = GRID_Y + ty - this.#scrollY;
    this.#hit(tx, screenY, s, s + 15, () => {
      sel ? this.#sel.delete(pose.id) : this.#sel.add(pose.id);
    });
  }

  // ── Scrollbar ─────────────────────────────────────────────────────────────

  #drawScrollbar(ctx, t, W) {
    const sb = this.#scrollbarRect();
    if (!sb) return;

    const trackY = GRID_Y, trackH = this.#gridH();

    // Track
    ctx.fillStyle = t.bg1;
    rr(ctx, sb.x, trackY, sb.w, trackH, 2); ctx.fill();

    // Thumb
    ctx.fillStyle = t.accent + "66";
    rr(ctx, sb.x, sb.y, sb.w, sb.h, 2); ctx.fill();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
app.registerExtension({
  name: "LoRaDaddy.PoseSelector",

  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "PoseSelector") return;
    if (nodeType.prototype.__psInit) return;
    nodeType.prototype.__psInit = true;

    const origCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function() {
      if (origCreated) origCreated.apply(this, arguments);
      if (!this.__psUI) this.__psUI = new PoseSelectorUI(this);
    };

    const origDraw = nodeType.prototype.onDrawForeground;
    nodeType.prototype.onDrawForeground = function(ctx) {
      if (origDraw) origDraw.call(this, ctx);
      this.__psUI?.draw(ctx);
    };
  },
});
