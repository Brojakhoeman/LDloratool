import os
import json
from aiohttp import web
try:
    from server import PromptServer
    THUMB_DIR = os.path.join(os.path.dirname(os.path.realpath(__file__)), "thumbnails")

    @PromptServer.instance.routes.get("/pose_selector/thumb/{name}")
    async def get_thumbnail(request):
        name = request.match_info["name"]
        if ".." in name or "/" in name or chr(92) in name:
            return web.Response(status=400)
        path = os.path.join(THUMB_DIR, name)
        if not os.path.exists(path):
            return web.Response(status=404)
        return web.FileResponse(path)
except Exception as e:
    print(f"[PoseSelector] Could not register thumbnail route: {e}")




# ─────────────────────────────────────────────────────────────────────────────
# Pose definitions — ordered for the UI grid
# Groups: Face Macros → Head/Bust Angles → Full Body → Medium/Torso → Lower/Genital Close-ups
# ─────────────────────────────────────────────────────────────────────────────
POSES = [
    # ── FACE MACROS ──────────────────────────────────────────────────────────
    {
        "id": "P02", "label": "Face Front",
        "group": "Face",
        "thumbnail": "P02_macro_face_straight_on",
        "prompt": "Camera positioned directly in front of the subject at eye level, subject centered in frame, neutral expression, straight-on portrait composition",
    },
    {
        "id": "P39", "label": "Face Macro",
        "group": "Face",
        "thumbnail": "P39_face_macro_straight_on",
        "prompt": "Camera close to the subject's face from straight on, extreme face macro, face filling entire frame from chin to forehead",
    },
    {
        "id": "P21", "label": "Eye Macro",
        "group": "Face",
        "thumbnail": "P21_macro_eye_closeup",
        "prompt": "Camera extremely close to the subject's eyes, macro eye close-up, both eyes filling the frame",
    },
    {
        "id": "P26", "label": "Lips Macro",
        "group": "Face",
        "thumbnail": "P26_lips_macro_closeup",
        "prompt": "Extreme close-up of the subject's lips and lower face, chin to nose filling the frame",
    },
    {
        "id": "P06", "label": "Face Upward",
        "group": "Face",
        "thumbnail": "P06_macro_face_upward_tilt_extreme",
        "prompt": "Camera extremely close to the subject's face, slight upward angle, chin tilted up, face filling entire frame",
    },
    {
        "id": "P16", "label": "Face Overhead",
        "group": "Face",
        "thumbnail": "P16_overhead_face_macro",
        "prompt": "Camera directly above the subject's face looking straight down, overhead face macro, face filling frame",
    },

    # ── HEAD / BUST ANGLES ───────────────────────────────────────────────────
    {
        "id": "P03", "label": "45° Left Bust",
        "group": "Head",
        "thumbnail": "P03_face_45_degree_left_profile",
        "prompt": "Camera angled 45 degrees to the subject's left side, subject's profile partially visible, medium close-up framing from shoulders upward",
    },
    {
        "id": "P37", "label": "45° Right Bust",
        "group": "Head",
        "thumbnail": "P37_right_45_bust",
        "prompt": "Camera angled 45 degrees to the subject's right side, subject's profile partially visible, medium close-up framing from shoulders upward",
    },
    {
        "id": "P36", "label": "Front Bust",
        "group": "Head",
        "thumbnail": "P36_front_bust_upward_gaze",
        "prompt": "Camera positioned directly in front of the subject at eye level, medium close-up framed from shoulders to top of head, slight upward gaze",
    },
    {
        "id": "P38", "label": "Top-Down Bust",
        "group": "Head",
        "thumbnail": "P38_top_down_three_quarter_bust",
        "prompt": "Camera positioned slightly above and in front, looking down at subject's face, three-quarter face view, framed from shoulders upward",
    },
    {
        "id": "P07", "label": "90° Right Profile",
        "group": "Head",
        "thumbnail": "P07_face_90_degree_side_profile_right",
        "prompt": "Camera positioned at 90 degrees to the subject's right, pure side profile, full head and neck visible",
    },
    {
        "id": "P11", "label": "90° Left Profile",
        "group": "Head",
        "thumbnail": "P11_face_90_degree_side_profile_left",
        "prompt": "Camera positioned at 90 degrees to the subject's left, pure left side profile, full head and neck visible",
    },
    {
        "id": "P30", "label": "45° Left Close",
        "group": "Head",
        "thumbnail": "P30_face_45_left_closeup",
        "prompt": "Camera close to the subject's face from the left side at 45 degrees, cheek and partial profile filling frame",
    },
    {
        "id": "P20", "label": "Chest Down Angle",
        "group": "Head",
        "thumbnail": "P20_chest_downward_angle",
        "prompt": "Camera framing from the chest upward at a slight downward angle, face and chest visible, looking down at subject",
    },

    # ── FULL BODY ────────────────────────────────────────────────────────────
    {
        "id": "P12", "label": "3/4 Front",
        "group": "Full Body",
        "thumbnail": "P12_three_quarter_body_front_knees_to_head",
        "prompt": "Camera framing the subject from the knees upward, subject standing, three-quarter body shot from the front",
    },
    {
        "id": "P19", "label": "Full Side Left",
        "group": "Full Body",
        "thumbnail": "P19_full_body_side_profile_left",
        "prompt": "Camera positioned at the subject's side, full body side profile from head to feet, 90 degrees left, naked, fully nude, no clothing",
    },
    {
        "id": "P29", "label": "Full Side Right",
        "group": "Full Body",
        "thumbnail": "P29_full_body_side_profile_right",
        "prompt": "Camera positioned at the subject's right side, full body side profile from head to feet, 90 degrees right, naked, fully nude, no clothing",
    },
    {
        "id": "P31", "label": "Rear Full",
        "group": "Full Body",
        "thumbnail": "P31_rear_full_body_standing_nude",
        "prompt": "Camera positioned directly behind the subject, rear view, full nude figure visible from head to feet, naked, fully nude, no clothing",
    },
    {
        "id": "P32", "label": "Rear 3/4",
        "group": "Full Body",
        "thumbnail": "P32_rear_three_quarter_full_body",
        "prompt": "Camera positioned behind and to the right at 45 degrees, rear three-quarter view, full body visible, naked, fully nude, no clothing",
    },
    {
        "id": "P33", "label": "Over Shoulder",
        "group": "Full Body",
        "thumbnail": "P33_over_shoulder_look_back",
        "prompt": "Subject looking back over their right shoulder, camera positioned behind at 45 degrees, face partially visible, naked, fully nude, no clothing",
    },
    {
        "id": "P08", "label": "Aerial Overhead",
        "group": "Full Body",
        "thumbnail": "P08_aerial_overhead_full_body",
        "prompt": "Camera positioned high above the subject looking straight down, aerial overhead view, full body visible",
    },
    {
        "id": "P27", "label": "High 3/4",
        "group": "Full Body",
        "thumbnail": "P27_high_angle_three_quarter_full_body",
        "prompt": "Camera positioned above and to the right at 45 degrees, high-angle three-quarter view, full body visible, naked, fully nude, no clothing",
    },
    {
        "id": "P22", "label": "Lying Overhead",
        "group": "Full Body",
        "thumbnail": "P22_overhead_lying_flat_full_body",
        "prompt": "Subject lying on their back, camera above looking down, full body visible from overhead while lying flat, naked, fully nude, no clothing",
    },
    {
        "id": "P28", "label": "Side Lying",
        "group": "Full Body",
        "thumbnail": "P28_side_lying_full_body",
        "prompt": "Subject lying on their side, camera at eye level in front, full side-lying body from head to feet, naked, fully nude, no clothing",
    },

    # ── MEDIUM / SEATED / POSED ──────────────────────────────────────────────
    {
        "id": "P09", "label": "Torso Front",
        "group": "Medium",
        "thumbnail": "P09_medium_torso_front_shoulders_to_hips",
        "prompt": "Medium shot of the subject's chest and torso from the front, framed from shoulders to hips",
    },
    {
        "id": "P14", "label": "Rear Waist-Up",
        "group": "Medium",
        "thumbnail": "P14_rear_medium_shot_waist_to_head",
        "prompt": "Camera close behind the subject, rear medium shot framed from waist to head, back of head and shoulders",
    },
    {
        "id": "P13", "label": "Seated Front",
        "group": "Medium",
        "thumbnail": "P13_seated_front_full_body",
        "prompt": "Subject seated on the ground, camera at eye level in front, legs extended forward, full seated body visible from head to feet, naked, fully nude, no clothing",
    },
    {
        "id": "P17", "label": "Kneeling",
        "group": "Medium",
        "thumbnail": "P17_kneeling_front_full_body",
        "prompt": "Subject kneeling, camera at eye level in front, full kneeling body visible, naked, fully nude, no clothing",
    },
    {
        "id": "P35", "label": "Wide Squat",
        "group": "Medium",
        "thumbnail": "P35_wide_squat_front",
        "prompt": "Subject in a wide squat position, camera at eye level in front, knees apart, full body visible, naked, fully nude, no clothing",
    },
    {
        "id": "P24", "label": "Bent Rear",
        "group": "Medium",
        "thumbnail": "P24_bent_forward_rear_overhead",
        "prompt": "Subject bent forward at the waist, camera behind and above, rear three-quarter overhead view, naked, fully nude, no clothing",
    },

    # ── LOWER / CLOSE-UPS ────────────────────────────────────────────────────
    {
        "id": "P10", "label": "Chest Upward",
        "group": "Lower",
        "thumbnail": "P10_chest_closeup_upward_angle",
        "prompt": "Camera close to the subject's chest from slightly below, breasts and collarbone filling the frame, upward angle",
    },
    {
        "id": "P23", "label": "Waist Front",
        "group": "Lower",
        "thumbnail": "P23_waist_height_front_medium",
        "prompt": "Camera positioned at waist height in front of the subject, waist and hips centered, medium close-up, naked, fully nude, no clothing",
    },
    {
        "id": "P18", "label": "Rear Lower",
        "group": "Lower",
        "thumbnail": "P18_rear_lower_back_closeup",
        "prompt": "Camera close to the subject's lower back and rear, medium close-up of the back from waist down, rear view, naked, fully nude, no clothing",
    },
    {
        "id": "P01", "label": "Groin Front",
        "group": "Lower",
        "thumbnail": "P01_macro_groin_standing_front",
        "prompt": "Close-up shot focused on the hips and groin area, subject standing, lower body filling frame",
    },
    {
        "id": "P04", "label": "Low Upward",
        "group": "Lower",
        "thumbnail": "P04_low_angle_upward_full_body_groin",
        "prompt": "Camera placed low, aimed upward toward the subject's lower torso, subject standing with legs apart, lower body filling the entire frame from below",
    },
    {
        "id": "P15", "label": "Ground Upward",
        "group": "Lower",
        "thumbnail": "P15_ground_level_extreme_upward",
        "prompt": "Camera positioned low at ground level looking straight up between the subject's legs, subject standing over camera, extreme upward perspective, full nude body visible from below, naked, fully nude, no clothing, genitals visible",
    },
    {
        "id": "P25", "label": "Ground Rear",
        "group": "Lower",
        "thumbnail": "P25_ground_level_rear_low_angle",
        "prompt": "Camera at floor level behind the subject, low rear angle, legs and lower body from behind at ground level, naked, fully nude, no clothing",
    },
]


class PoseSelector:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "selected_poses": ("STRING", {"default": "", "multiline": True}),
                "gender": (["neutral", "woman", "man"], {"default": "neutral"}),
                "nude": ("BOOLEAN", {"default": True}),
                "custom_append": ("STRING", {"default": "", "multiline": False}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING",)
    RETURN_NAMES = ("prompts", "captions",)
    FUNCTION = "generate_prompts"
    CATEGORY = "LoRa-Daddy/Dataset"
    OUTPUT_IS_LIST = (True, True,)

    @classmethod
    def get_poses_json(cls):
        return json.dumps(POSES)

    def generate_prompts(self, selected_poses, gender, nude, custom_append):
        # Parse selected pose IDs from comma-separated string
        if not selected_poses.strip():
            return ([""], [""],)

        selected_ids = [p.strip() for p in selected_poses.split(",") if p.strip()]
        pose_map = {p["id"]: p for p in POSES}

        prompts = []
        captions = []
        for pid in selected_ids:
            if pid not in pose_map:
                continue
            prompt = pose_map[pid]["prompt"]

            # Build suffix parts
            parts = []
            if gender != "neutral":
                parts.append(gender)
            if nude:
                # Only add nude tag if not already in prompt
                if "naked" not in prompt:
                    parts.append("naked, fully nude, no clothing")
            else:
                # Explicitly enforce clothed so model doesn't guess
                parts.append("fully clothed")
            if custom_append.strip():
                parts.append(custom_append.strip())

            if parts:
                prompt = prompt.rstrip(", ") + ", " + ", ".join(parts)

            prompts.append(prompt)
            # Caption = same as prompt — wire into Dataset Save Image caption pin
            captions.append(prompt)

        if not prompts:
            return ([""], [""],)

        print(f"[PoseSelector] 📸 Outputting {len(prompts)} pose prompts")
        for i, p in enumerate(prompts, 1):
            print(f"[PoseSelector]   {i}. {p[:80]}...")

        return (prompts, captions,)


NODE_CLASS_MAPPINGS = {"PoseSelector": PoseSelector}
NODE_DISPLAY_NAME_MAPPINGS = {"PoseSelector": "📸 Pose Selector"}
WEB_DIRECTORY = os.path.join(os.path.dirname(os.path.realpath(__file__)), "web")
