"""
Dataset Save Image — Illustrious / SDXL Training Node
LoRa-Daddy

Saves generated images to a dataset folder with matching .txt caption sidecar.
Filename is zero-padded sequential index — safe to resume.

Inputs:
  images      — IMAGE tensor from sampler / VAE decode
  caption     — STRING (wire the prompt output directly here)
  output_dir  — Full path to dataset folder  (e.g. D:/datasets/my_lora)
  subfolder   — Optional subfolder inside output_dir
  prefix      — Optional trigger word prepended to every caption
  suffix      — Optional suffix appended to every caption
  file_format — png or jpg
  jpg_quality — JPEG quality 1-100 (ignored for PNG)
  overwrite   — If False, skips files that already exist (safe resume)
  enabled     — Pause without stopping Auto Queue

Outputs:
  saved_path   — Full path of the image that was saved
  caption_path — Full path of the .txt that was saved
  file_index   — The index used for this file (useful for logging)
"""

import os
import re
import time
import numpy as np

try:
    from PIL import Image as PILImage
except ImportError:
    PILImage = None


class DatasetSaveImage:
    """
    💾 Dataset Save Image
    LoRa-Daddy

    Saves IMAGE tensor + caption string as image/.txt sidecar pair.
    Wire the prompt output from the dataset node directly into caption.
    """

    _session_index = None
    _session_dir   = None

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "caption": ("STRING", {
                    "default": "",
                    "multiline": True,
                    "tooltip": "Caption text — wire from dataset node prompt output.",
                }),
                "output_dir": ("STRING", {
                    "default": "D:/datasets/my_lora",
                    "tooltip": "Absolute path to the folder where images and .txt files are saved.",
                }),
                "file_format": (["png", "jpg"], {"default": "png"}),
                "jpg_quality": ("INT", {
                    "default": 95, "min": 1, "max": 100, "step": 1,
                    "tooltip": "JPEG quality (ignored when file_format is png).",
                }),
                "overwrite": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "False = skip if file already exists (safe resume). True = always overwrite.",
                }),
                "enabled": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Disable to pause without stopping Auto Queue.",
                }),
                "target_count": ("INT", {
                    "default": 20, "min": 1, "max": 500, "step": 1,
                    "tooltip": "Total images expected. When saved count >= this, trigger=True fires to start LoRA training.",
                }),
            },
            "optional": {
                "subfolder": ("STRING", {
                    "default": "",
                    "tooltip": "Optional subfolder inside output_dir.",
                }),
                "prefix": ("STRING", {
                    "default": "",
                    "tooltip": "Trigger word or text prepended to every caption.",
                }),
                "suffix": ("STRING", {
                    "default": "",
                    "tooltip": "Text appended to every caption.",
                }),
                "filename_prefix": ("STRING", {
                    "default": "img",
                    "tooltip": "Filename prefix before the zero-padded index.",
                }),
            },
        }

    RETURN_TYPES  = ("STRING", "STRING", "INT", "BOOLEAN",)
    RETURN_NAMES  = ("saved_path", "caption_path", "file_index", "trigger",)
    FUNCTION      = "execute"
    CATEGORY      = "LoRa-Daddy/Dataset"
    OUTPUT_NODE   = True

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return time.time()

    # ── index persistence across auto-queue runs ─────────────────────────────
    @classmethod
    def _get_next_index(cls, folder, file_format, filename_prefix, overwrite):
        """
        Scan folder for existing files to find the next safe index.
        Only called once per session (when dir changes or on first run).
        """
        prefix = filename_prefix or "img"
        pattern = re.compile(
            rf"^{re.escape(prefix)}_(\d+)\.{file_format}$", re.IGNORECASE
        )
        max_idx = -1
        try:
            for fname in os.listdir(folder):
                m = pattern.match(fname)
                if m:
                    idx = int(m.group(1))
                    if idx > max_idx:
                        max_idx = idx
        except Exception:
            pass
        return 0 if overwrite else max_idx + 1

    def execute(self, images, caption, output_dir, file_format,
                jpg_quality, overwrite, enabled, target_count=20,
                subfolder="", prefix="", suffix="", filename_prefix="img"):

        if not enabled:
            return ("", "", -1, False,)

        if PILImage is None:
            raise RuntimeError("[DatasetSaveImage] Pillow not installed — pip install pillow")

        # ── Resolve output folder ─────────────────────────────────────────────
        folder = os.path.join(output_dir, subfolder.strip()) if subfolder.strip() else output_dir
        os.makedirs(folder, exist_ok=True)

        fp = (filename_prefix or "img").strip()

        # ── Session index: reset if folder changed ────────────────────────────
        if DatasetSaveImage._session_dir != folder:
            DatasetSaveImage._session_dir   = folder
            DatasetSaveImage._session_index = self._get_next_index(folder, file_format, fp, overwrite)
            print(f"[DatasetSaveImage] New session → folder: {folder} | starting index: {DatasetSaveImage._session_index}")

        # ── Handle batch: images shape [N, H, W, C], caption may be single or list ──
        # When PoseSelector outputs N prompts, ComfyUI runs the node once per prompt
        # BUT if images is a batch tensor with N frames, save them all here.
        batch_size = images.shape[0]

        # Normalise caption to a list matching batch size
        if isinstance(caption, (list, tuple)):
            captions = list(caption)
        else:
            captions = [caption] * batch_size

        # Pad or trim to batch size
        if len(captions) < batch_size:
            captions = captions + [captions[-1]] * (batch_size - len(captions))
        captions = captions[:batch_size]

        saved_paths   = []
        caption_paths = []
        first_idx     = DatasetSaveImage._session_index

        for i in range(batch_size):
            idx = DatasetSaveImage._session_index

            img_name = f"{fp}_{idx:06d}.{file_format}"
            txt_name = f"{fp}_{idx:06d}.txt"
            img_path = os.path.join(folder, img_name)
            txt_path = os.path.join(folder, txt_name)

            # ── Skip if exists and not overwriting ────────────────────────────
            if not overwrite and os.path.exists(img_path):
                print(f"[DatasetSaveImage] SKIP (exists): {img_name}")
                DatasetSaveImage._session_index += 1
                saved_paths.append(img_path)
                caption_paths.append(txt_path)
                continue

            # ── Convert tensor → PIL ──────────────────────────────────────────
            img_np = images[i].cpu().numpy()
            img_np = (img_np * 255).clip(0, 255).astype(np.uint8)
            pil_img = PILImage.fromarray(img_np, mode="RGB")

            # ── Save image ────────────────────────────────────────────────────
            if file_format == "jpg":
                pil_img.save(img_path, format="JPEG", quality=jpg_quality, optimize=True)
            else:
                pil_img.save(img_path, format="PNG", optimize=True)

            # ── Build and save caption ────────────────────────────────────────
            parts = []
            if prefix.strip():
                parts.append(prefix.strip().rstrip(","))
            cap = captions[i]
            if isinstance(cap, str) and cap.strip():
                parts.append(cap.strip())
            if suffix.strip():
                parts.append(suffix.strip())

            caption_text = ", ".join(parts) if parts else ""

            with open(txt_path, "w", encoding="utf-8") as fh:
                fh.write(caption_text)

            print(f"[DatasetSaveImage] [{idx:06d}] Saved: {img_name}  |  caption: {caption_text[:80]}...")

            DatasetSaveImage._session_index += 1
            saved_paths.append(img_path)
            caption_paths.append(txt_path)

        # Count total images now on disk to check if target reached
        try:
            all_imgs = [f for f in os.listdir(folder)
                        if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp"))]
            total_on_disk = len(all_imgs)
        except Exception:
            total_on_disk = len(saved_paths)

        trigger = total_on_disk >= target_count
        if trigger:
            print(f"[DatasetSaveImage] 🎯 Target reached: {total_on_disk}/{target_count} images — trigger=True, sending to trainer!")
        else:
            print(f"[DatasetSaveImage] 📁 Progress: {total_on_disk}/{target_count} images saved.")

        return (saved_paths[0] if saved_paths else "",
                caption_paths[0] if caption_paths else "",
                first_idx,
                trigger,)


# ══════════════════════════════════════════════════════════════════════════
#  REGISTRATION (standalone — overridden by __init__.py when in package)
# ══════════════════════════════════════════════════════════════════════════

NODE_CLASS_MAPPINGS        = {"DatasetSaveImage": DatasetSaveImage}
NODE_DISPLAY_NAME_MAPPINGS = {"DatasetSaveImage": "💾 Dataset Save Image"}
