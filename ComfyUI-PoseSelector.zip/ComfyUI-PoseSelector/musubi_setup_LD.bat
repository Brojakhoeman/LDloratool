@echo off
setlocal enabledelayedexpansion
title Musubi Tuner - LoRa-Daddy Full Setup
color 0A

echo.
echo  ================================================
echo   LoRa-Daddy - Musubi Tuner Full Setup
echo   LTX-2.3 LoRA Training Pipeline
echo   Musubi + LTX-2.3 model + Gemma text encoder
echo  ================================================
echo.
echo  This installer will:
echo    1. Install Musubi Tuner (AkaneTendo25 ltx-2 branch)
echo    2. Create a Python venv with all dependencies
echo    3. Download LTX-2.3-22b-dev transformer (~22GB)
echo    4. Download Gemma-3 text encoder (~8GB)
echo    5. Configure paths so the ComfyUI node works instantly
echo.
echo  Total download: ~30GB
echo  Make sure you have space and a good connection.
echo.
pause

:: ============================================================
:: DRIVE SELECTION
:: ============================================================
echo.
echo  Detecting available drives...
echo.

set DRIVE_COUNT=0
for %%d in (C D E F G H I J K L M) do (
    if exist "%%d:\" (
        set /a DRIVE_COUNT+=1
        echo    %%d:\
    )
)
echo.
echo  ================================================
echo   Where would you like to install Musubi?
echo.
echo   Default is C:\Musubi - this is what the
echo   ComfyUI node expects by default.
echo.
echo   Press ENTER to install to C:\Musubi
echo   OR type a drive letter (e.g. D) to use D:\Musubi
echo  ================================================
echo.
set DRIVE_CHOICE=
set /p DRIVE_CHOICE=  Your choice (ENTER for C): 

if "!DRIVE_CHOICE!"=="" set DRIVE_CHOICE=C
if /i "!DRIVE_CHOICE!"=="Y" set DRIVE_CHOICE=C
if /i "!DRIVE_CHOICE!"=="yes" set DRIVE_CHOICE=C

:: Take only first character
set DRIVE_CHOICE=!DRIVE_CHOICE:~0,1!

:: Validate
if not exist "!DRIVE_CHOICE!:\" (
    echo  Drive !DRIVE_CHOICE!:\ not found. Defaulting to C:
    set DRIVE_CHOICE=C
)

set INSTALL_DIR=!DRIVE_CHOICE!:\Musubi
set MODELS_DIR=!INSTALL_DIR!\models
set GEMMA_DIR=!MODELS_DIR!\gemma-3-12b-it-qat-q4_0-unquantized
set REPO_URL=https://github.com/AkaneTendo25/musubi-tuner.git
set BRANCH=ltx-2

echo.
echo  ================================================
echo   Install path : !INSTALL_DIR!
echo   Models path  : !MODELS_DIR!
echo  ================================================
echo.
if /i NOT "!DRIVE_CHOICE!"=="C" (
    echo  NOTE: You chose !DRIVE_CHOICE!:\Musubi
    echo  After setup, set musubi_dir in the Trainer node to:
    echo    !INSTALL_DIR!
    echo.
)
pause

:: ============================================================
:: STEP 1 - Check Git
:: ============================================================
echo.
echo [1/8] Checking for Git...
git --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ERROR: Git is not installed or not in PATH.
    echo  Install from: https://git-scm.com/download/win
    echo  Then re-run this script.
    echo.
    pause & exit /b 1
)
git --version
echo  Git OK.

:: ============================================================
:: STEP 2 - Check Python
:: ============================================================
echo.
echo [2/8] Checking for Python 3.10+...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ERROR: Python not found in PATH.
    echo  Install Python 3.10 or 3.11 from: https://www.python.org/
    echo  Tick "Add Python to PATH" during install.
    echo.
    pause & exit /b 1
)
python --version
echo  Python OK.

:: ============================================================
:: STEP 3 - Clone Musubi
:: ============================================================
echo.
echo [3/8] Cloning Musubi Tuner into !INSTALL_DIR!...
if exist "!INSTALL_DIR!\.git" (
    echo  Already cloned - pulling latest changes...
    cd /d "!INSTALL_DIR!"
    git pull
) else (
    git clone --branch !BRANCH! !REPO_URL! "!INSTALL_DIR!"
    if errorlevel 1 (
        echo.
        echo  ERROR: Clone failed. Check your internet connection.
        pause & exit /b 1
    )
)
cd /d "!INSTALL_DIR!"
echo  Clone OK.

:: ============================================================
:: STEP 4 - Create venv
:: ============================================================
echo.
echo [4/8] Creating virtual environment...
if not exist "!INSTALL_DIR!\venv\Scripts\python.exe" (
    python -m venv venv
    if errorlevel 1 (
        echo  ERROR: Failed to create venv.
        pause & exit /b 1
    )
    echo  venv created.
) else (
    echo  venv already exists, skipping.
)

:: ============================================================
:: STEP 5 - Install PyTorch + deps
:: ============================================================
echo.
echo [5/8] Installing PyTorch (CUDA 12.4) and dependencies...
echo  This may take 10-20 minutes on first run.
echo.
call venv\Scripts\activate.bat

pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128 --quiet
if errorlevel 1 (
    echo  ERROR: PyTorch install failed.
    pause & exit /b 1
)

pip install -e . --quiet
if errorlevel 1 (
    echo  ERROR: musubi-tuner install failed.
    pause & exit /b 1
)

pip install ascii-magic matplotlib tensorboard prompt-toolkit bitsandbytes huggingface-hub --quiet
echo  All dependencies installed.

:: ============================================================
:: STEP 6 - Download LTX-2.3 transformer
:: ============================================================
echo.
echo [6/8] Downloading LTX-2.3-22b-dev transformer (~22GB)...
echo.

if not exist "!MODELS_DIR!" mkdir "!MODELS_DIR!"

set LTX_FILE=!MODELS_DIR!\ltx-2.3-22b-dev.safetensors
if exist "!LTX_FILE!" (
    echo  LTX-2.3 transformer already exists at !LTX_FILE! - skipping.
) else (
    echo  Downloading - this will take a while depending on your connection.
    echo  Do not close this window.
    echo.
    python -c "import urllib.request, sys; url='https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-22b-dev.safetensors'; dest=r'!LTX_FILE!'; print('Starting download...'); urllib.request.urlretrieve(url, dest, lambda b,bs,ts: print(f'  {b*bs/1024/1024:.0f} MB / {ts/1024/1024:.0f} MB', end=chr(13))); print('  Download complete.          ')"
    if errorlevel 1 (
        echo.
        echo  WARNING: Download failed. You can retry by re-running this script,
        echo  or manually download from:
        echo  https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-22b-dev.safetensors
        echo  and place it in: !MODELS_DIR!\
        echo.
    ) else (
        echo  LTX-2.3 transformer saved to !LTX_FILE!
    )
)

:: ============================================================
:: STEP 7 - Download Gemma text encoder
:: ============================================================
echo.
echo [7/8] Downloading Gemma-3 text encoder (~8GB)...
echo.

if not exist "!GEMMA_DIR!" mkdir "!GEMMA_DIR!"

:: Check if already populated (more than just the folder)
set GEMMA_FILE_COUNT=0
for %%f in ("!GEMMA_DIR!\*") do set /a GEMMA_FILE_COUNT+=1

if !GEMMA_FILE_COUNT! GTR 2 (
    echo  Gemma folder already has files - skipping download.
) else (
    echo  Downloading all files from:
    echo  https://huggingface.co/google/gemma-3-12b-it-qat-q4_0-unquantized
    echo.
    echo  NOTE: If this fails, you may need to accept the Gemma license first:
    echo  1. Go to https://huggingface.co/google/gemma-3-12b-it-qat-q4_0-unquantized
    echo  2. Click "Access repository" and accept the terms
    echo  3. Run: huggingface-cli login
    echo  4. Re-run this script
    echo.
    python -c "from huggingface_hub import snapshot_download; snapshot_download(repo_id='google/gemma-3-12b-it-qat-q4_0-unquantized', local_dir=r'!GEMMA_DIR!', local_dir_use_symlinks=False); print('Gemma download complete')"
    if errorlevel 1 (
        echo.
        echo  WARNING: Gemma download failed.
        echo  Please follow the steps above, then re-run this script.
        echo  The folder !GEMMA_DIR! has been created ready for the files.
        echo.
    ) else (
        echo  Gemma text encoder saved to !GEMMA_DIR!
    )
)

:: ============================================================
:: STEP 8 - Accelerate config + write node config
:: ============================================================
echo.
echo [8/8] Configuring Accelerate for single-GPU bf16...
echo.
echo  Press ENTER for all questions EXCEPT mixed_precision:
echo  When asked for mixed precision - type:  bf16
echo.
pause
accelerate config

:: Write loradaddy_config.json so the ComfyUI node auto-fills paths
echo.
echo  Writing path config for ComfyUI node...

set CONFIG_FILE=!INSTALL_DIR!\loradaddy_config.json
set LTX_JSON=!LTX_FILE:\=\\!
set GEMMA_JSON=!GEMMA_DIR:\=\\!
set INSTALL_JSON=!INSTALL_DIR:\=\\!

(
    echo {
    echo   "musubi_dir": "!INSTALL_JSON!",
    echo   "transformer": "!LTX_JSON!",
    echo   "gemma_root": "!GEMMA_JSON!"
    echo }
) > "!CONFIG_FILE!"

echo  Config saved to: !CONFIG_FILE!

:: ============================================================
:: DONE
:: ============================================================
echo.
echo  ================================================
echo   Setup complete!
echo  ================================================
echo   Musubi     : !INSTALL_DIR!
echo   Transformer: !LTX_FILE!
echo   Gemma      : !GEMMA_DIR!
echo  ================================================
echo.
echo   Next steps:
echo   1. Drop ComfyUI-PoseSelector into your custom_nodes folder
echo   2. Restart ComfyUI
echo   3. Find nodes under LoRa-Daddy/Dataset and Training
if /i NOT "!DRIVE_CHOICE!"=="C" (
    echo   4. In the Trainer node set musubi_dir to: !INSTALL_DIR!
)
echo.
pause
