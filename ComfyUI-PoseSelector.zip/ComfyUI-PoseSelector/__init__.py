from .pose_selector import (
    NODE_CLASS_MAPPINGS as _PS,
    NODE_DISPLAY_NAME_MAPPINGS as _PS_N,
    WEB_DIRECTORY,
)
from .dataset_save_image import (
    NODE_CLASS_MAPPINGS as _DSI,
    NODE_DISPLAY_NAME_MAPPINGS as _DSI_N,
)
from .musubi_trainer_node import (
    NODE_CLASS_MAPPINGS as _MT,
    NODE_DISPLAY_NAME_MAPPINGS as _MT_N,
)

NODE_CLASS_MAPPINGS        = {**_PS, **_DSI, **_MT}
NODE_DISPLAY_NAME_MAPPINGS = {**_PS_N, **_DSI_N, **_MT_N}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
